first run ipynb to get generated_symfuncs.txt, remember to change the element and parameter as you need. 


still paste the input.data input.nn here

copy the generated_symfuncs.txt to substitute the part of symfuncs in the input.nn,save

open the terminal and enter



1. ~/n2p2/bin/nnp-scaling 500

to get function.data

2. python clean_symfunc_data.py function.data

to get cleaned_symfunc.csv 

3. python plot_symfunc_corr.py cleaned_symfunc.csv --output my_heatmap.png --tick 100

to plot picture

4. python symfunc_filter_and_plot.py cleaned_symfunc.csv

can see outputs like these

[✓] Loaded data from cleaned_symfunc.csv, shape: (768, 1501)
[✓] Removed 1 constant columns.
[✓] Data standardized (zero mean, unit variance).
[✓] Threshold 0.99: 196 functions retained, 1304 pairs removed
[+] Saved: filtered_heatmap_99.png
[✓] Threshold 0.95: 77 functions retained, 1423 pairs removed
[+] Saved: filtered_heatmap_95.png
[✓] Threshold 0.9: 48 functions retained, 1452 pairs removed
[+] Saved: filtered_heatmap_90.png
[✓] Threshold 0.85: 36 functions retained, 1464 pairs removed
[+] Saved: filtered_heatmap_85.png
[✓] Threshold 0.8: 32 functions retained, 1468 pairs removed
[+] Saved: filtered_heatmap_80.png
[+] Saved: retained_vs_threshold.png

5. python batch_filter_symfuncs.py generated_symfuncs.txt

to get all the filtered symfuncs.txt find the one you want and paste to a new input.nn for training.


